
import React, { useState } from 'react';
import { Button } from "@/components/ui/button";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { useToast } from "@/hooks/use-toast";
import { Loader2 } from 'lucide-react';
import Header from '@/components/Header';
import Footer from '@/components/Footer';
import UploadZone from '@/components/UploadZone';
import ResultsVisualization from '@/components/ResultsVisualization';

interface DetectionResult {
  originalImage: string;
  processedImage: string;
  metrics: {
    precision: number;
    recall: number;
    f1Score: number;
    iou: number;
    confidence: number;
  };
}

const Detector = () => {
  const [isProcessing, setIsProcessing] = useState(false);
  const [uploadedImage, setUploadedImage] = useState<string | null>(null);
  const [result, setResult] = useState<DetectionResult | null>(null);
  const { toast } = useToast();

  // This would be replaced with actual API call to your Python backend
  const analyzeImage = (image: File) => {
    setIsProcessing(true);
    
    // Create a URL for the uploaded image to display
    const imageUrl = URL.createObjectURL(image);
    setUploadedImage(imageUrl);
    
    // Simulate API call delay
    setTimeout(() => {
      // Mock result - in a real app, this would come from your Python backend
      const mockResult: DetectionResult = {
        originalImage: imageUrl,
        processedImage: imageUrl, // In real app, this would be a processed image with forgery highlighted
        metrics: {
          precision: 0.92,
          recall: 0.88,
          f1Score: 0.90,
          iou: 0.85,
          confidence: 0.78 // Confidence that the image is forged
        }
      };
      
      setResult(mockResult);
      setIsProcessing(false);
      
      toast({
        title: "Analysis Complete",
        description: "Your image has been analyzed for forgery.",
      });
    }, 3000);
  };

  const handleUpload = (files: File[]) => {
    if (files.length > 0) {
      analyzeImage(files[0]);
    }
  };

  const resetAnalysis = () => {
    setUploadedImage(null);
    setResult(null);
  };

  return (
    <div className="flex flex-col min-h-screen">
      <Header />
      
      <main className="flex-grow container mx-auto px-4 py-8">
        <div className="max-w-5xl mx-auto">
          <h1 className="text-3xl font-bold mb-2">Image Forgery Detector</h1>
          <p className="text-muted-foreground mb-8">
            Upload an image to detect potential forgery using our advanced GNN-based model
          </p>
          
          <Tabs defaultValue="upload" className="space-y-6">
            <TabsList>
              <TabsTrigger value="upload">Upload Image</TabsTrigger>
              <TabsTrigger value="url" disabled>URL (Coming Soon)</TabsTrigger>
              <TabsTrigger value="camera" disabled>Camera (Coming Soon)</TabsTrigger>
            </TabsList>
            
            <TabsContent value="upload" className="space-y-6">
              {!result ? (
                <Card>
                  <CardHeader>
                    <CardTitle>Upload Image for Analysis</CardTitle>
                    <CardDescription>
                      Upload a JPG or PNG image to analyze for potential forgery
                    </CardDescription>
                  </CardHeader>
                  <CardContent>
                    <UploadZone 
                      onUpload={handleUpload}
                      isLoading={isProcessing}
                      accept="image/jpeg,image/png"
                      maxSize={10}
                    />
                  </CardContent>
                </Card>
              ) : (
                <div className="space-y-6">
                  <div className="flex justify-between items-center">
                    <h2 className="text-2xl font-bold">Analysis Results</h2>
                    <Button variant="outline" onClick={resetAnalysis}>
                      Analyze Another Image
                    </Button>
                  </div>
                  
                  <ResultsVisualization 
                    originalImage={result.originalImage}
                    processedImage={result.processedImage}
                    metrics={result.metrics}
                  />
                </div>
              )}
            </TabsContent>
          </Tabs>
          
          {isProcessing && (
            <div className="mt-8 flex flex-col items-center justify-center">
              <Loader2 className="h-8 w-8 text-primary animate-spin mb-4" />
              <p className="text-lg font-medium text-center">Analyzing Image</p>
              <p className="text-sm text-muted-foreground text-center">
                This may take a few moments as our model processes your image
              </p>
            </div>
          )}
        </div>
      </main>
      
      <Footer />
    </div>
  );
};

export default Detector;
