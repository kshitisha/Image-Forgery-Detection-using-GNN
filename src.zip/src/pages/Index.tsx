
import React from 'react';
import { Link } from 'react-router-dom';
import { Button } from "@/components/ui/button";
import { FileImage, BarChart2, Shield, Zap } from 'lucide-react';
import Header from '@/components/Header';
import Footer from '@/components/Footer';

const Index = () => {
  return (
    <div className="flex flex-col min-h-screen">
      <Header />
      
      <main className="flex-grow">
        {/* Hero Section */}
        <section className="gradient-bg py-16 md:py-24">
          <div className="container mx-auto px-4 flex flex-col-reverse md:flex-row items-center">
            <div className="md:w-1/2 text-center md:text-left mt-10 md:mt-0">
              <h1 className="text-4xl md:text-5xl font-bold mb-4">
                Advanced Image <span className="text-primary">Forgery Detection</span>
              </h1>
              <p className="text-xl text-muted-foreground mb-8 max-w-lg">
                Utilizing graph neural networks and computer vision to detect manipulated images with high accuracy.
              </p>
              <div className="flex flex-col sm:flex-row gap-4 justify-center md:justify-start">
                <Button size="lg" asChild>
                  <Link to="/detector">
                    <FileImage className="mr-2 h-5 w-5" />
                    Try the Detector
                  </Link>
                </Button>
                <Button variant="outline" size="lg" asChild>
                  <Link to="/results">
                    <BarChart2 className="mr-2 h-5 w-5" />
                    View Results
                  </Link>
                </Button>
              </div>
            </div>
            
            <div className="md:w-1/2 flex justify-center mb-8 md:mb-0">
              <div className="relative">
                <img 
                  src="/placeholder.svg" 
                  alt="Image Forgery Detection" 
                  className="w-full max-w-md rounded-md shadow-lg"
                />
                <div className="absolute -bottom-4 -right-4 bg-primary text-white px-4 py-2 rounded-md text-sm font-medium">
                  Powered by GNN
                </div>
              </div>
            </div>
          </div>
        </section>
        
        {/* Features Section */}
        <section className="py-16 bg-card">
          <div className="container mx-auto px-4">
            <h2 className="text-3xl font-bold text-center mb-12">Key Features</h2>
            
            <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-8">
              <div className="bg-background p-6 rounded-lg shadow-sm result-card">
                <div className="bg-primary/10 p-3 rounded-full w-12 h-12 flex items-center justify-center mb-4">
                  <FileImage className="h-6 w-6 text-primary" />
                </div>
                <h3 className="text-xl font-bold mb-3">Superpixel Analysis</h3>
                <p className="text-muted-foreground">
                  Segments images into superpixels to perform detailed analysis of local regions for more accurate forgery detection.
                </p>
              </div>
              
              <div className="bg-background p-6 rounded-lg shadow-sm result-card">
                <div className="bg-primary/10 p-3 rounded-full w-12 h-12 flex items-center justify-center mb-4">
                  <Shield className="h-6 w-6 text-primary" />
                </div>
                <h3 className="text-xl font-bold mb-3">Graph Neural Network</h3>
                <p className="text-muted-foreground">
                  Uses advanced GNN architecture to model spatial relationships between image regions and detect inconsistencies.
                </p>
              </div>
              
              <div className="bg-background p-6 rounded-lg shadow-sm result-card">
                <div className="bg-primary/10 p-3 rounded-full w-12 h-12 flex items-center justify-center mb-4">
                  <Zap className="h-6 w-6 text-primary" />
                </div>
                <h3 className="text-xl font-bold mb-3">High Performance</h3>
                <p className="text-muted-foreground">
                  Achieves over 90% precision and recall in detecting various types of image manipulations and forgeries.
                </p>
              </div>
            </div>
          </div>
        </section>
        
        {/* How It Works */}
        <section className="py-16">
          <div className="container mx-auto px-4">
            <div className="max-w-3xl mx-auto text-center">
              <h2 className="text-3xl font-bold mb-4">How It Works</h2>
              <p className="text-lg text-muted-foreground mb-12">
                Our advanced algorithm detects image forgery through a multi-stage process
              </p>
            </div>
            
            <div className="max-w-4xl mx-auto">
              <div className="relative">
                <div className="hidden md:block absolute top-0 bottom-0 left-16 w-1 bg-border"></div>
                
                <div className="space-y-12">
                  <div className="relative flex items-start">
                    <div className="hidden md:flex items-center justify-center w-32 absolute">
                      <div className="z-10 bg-primary text-white w-10 h-10 rounded-full flex items-center justify-center font-bold text-lg">
                        1
                      </div>
                    </div>
                    <div className="md:ml-40">
                      <div className="md:hidden bg-primary text-white w-10 h-10 rounded-full flex items-center justify-center font-bold text-lg mb-4">
                        1
                      </div>
                      <h3 className="text-xl font-bold mb-2">Image Segmentation</h3>
                      <p className="text-muted-foreground mb-4">
                        The input image is segmented into superpixels using the SLIC algorithm to group similar pixels together.
                      </p>
                    </div>
                  </div>
                  
                  <div className="relative flex items-start">
                    <div className="hidden md:flex items-center justify-center w-32 absolute">
                      <div className="z-10 bg-primary text-white w-10 h-10 rounded-full flex items-center justify-center font-bold text-lg">
                        2
                      </div>
                    </div>
                    <div className="md:ml-40">
                      <div className="md:hidden bg-primary text-white w-10 h-10 rounded-full flex items-center justify-center font-bold text-lg mb-4">
                        2
                      </div>
                      <h3 className="text-xl font-bold mb-2">Feature Extraction</h3>
                      <p className="text-muted-foreground mb-4">
                        Deep features are extracted from each superpixel using a pre-trained ResNet model to capture visual patterns.
                      </p>
                    </div>
                  </div>
                  
                  <div className="relative flex items-start">
                    <div className="hidden md:flex items-center justify-center w-32 absolute">
                      <div className="z-10 bg-primary text-white w-10 h-10 rounded-full flex items-center justify-center font-bold text-lg">
                        3
                      </div>
                    </div>
                    <div className="md:ml-40">
                      <div className="md:hidden bg-primary text-white w-10 h-10 rounded-full flex items-center justify-center font-bold text-lg mb-4">
                        3
                      </div>
                      <h3 className="text-xl font-bold mb-2">Graph Construction</h3>
                      <p className="text-muted-foreground mb-4">
                        A graph is constructed where nodes represent superpixels and edges connect adjacent regions in the image.
                      </p>
                    </div>
                  </div>
                  
                  <div className="relative flex items-start">
                    <div className="hidden md:flex items-center justify-center w-32 absolute">
                      <div className="z-10 bg-primary text-white w-10 h-10 rounded-full flex items-center justify-center font-bold text-lg">
                        4
                      </div>
                    </div>
                    <div className="md:ml-40">
                      <div className="md:hidden bg-primary text-white w-10 h-10 rounded-full flex items-center justify-center font-bold text-lg mb-4">
                        4
                      </div>
                      <h3 className="text-xl font-bold mb-2">GNN Analysis</h3>
                      <p className="text-muted-foreground mb-4">
                        The Graph Neural Network analyzes relationships between regions to detect inconsistencies that indicate manipulation.
                      </p>
                    </div>
                  </div>
                </div>
              </div>
            </div>
          </div>
        </section>
        
        {/* Call to Action */}
        <section className="py-16 bg-primary text-primary-foreground">
          <div className="container mx-auto px-4 text-center">
            <h2 className="text-3xl font-bold mb-4">Ready to Detect Image Forgery?</h2>
            <p className="text-xl mb-8 opacity-90 max-w-2xl mx-auto">
              Try our advanced detection tool now to analyze your images and identify potential manipulations.
            </p>
            <Button size="lg" variant="secondary" asChild>
              <Link to="/detector">Get Started</Link>
            </Button>
          </div>
        </section>
      </main>
      
      <Footer />
    </div>
  );
};

export default Index;
