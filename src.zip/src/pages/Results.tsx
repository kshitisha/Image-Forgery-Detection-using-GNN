
import React from 'react';
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import Header from '@/components/Header';
import Footer from '@/components/Footer';
import ModelMetrics from '@/components/ModelMetrics';

// Sample data for gallery
const exampleResults = [
  {
    id: 1,
    title: 'Spliced Face',
    image: '/placeholder.svg',
    description: 'Face region was replaced with another person',
    metrics: { precision: 0.94, recall: 0.91, f1Score: 0.92 }
  },
  {
    id: 2,
    title: 'Object Removal',
    image: '/placeholder.svg',
    description: 'An object was removed from the scene',
    metrics: { precision: 0.89, recall: 0.87, f1Score: 0.88 }
  },
  {
    id: 3,
    title: 'Copy-Move Forgery',
    image: '/placeholder.svg',
    description: 'Part of the image was copied and pasted elsewhere',
    metrics: { precision: 0.92, recall: 0.88, f1Score: 0.90 }
  },
  {
    id: 4,
    title: 'Color Manipulation',
    image: '/placeholder.svg',
    description: 'Local color alterations were made',
    metrics: { precision: 0.86, recall: 0.82, f1Score: 0.84 }
  }
];

const Results = () => {
  return (
    <div className="flex flex-col min-h-screen">
      <Header />
      
      <main className="flex-grow container mx-auto px-4 py-8">
        <h1 className="text-3xl font-bold mb-2">Model Results & Performance</h1>
        <p className="text-muted-foreground mb-8">
          Explore the performance metrics of our image forgery detection model
        </p>
        
        <Tabs defaultValue="metrics" className="space-y-6">
          <TabsList className="grid w-full grid-cols-2">
            <TabsTrigger value="metrics">Performance Metrics</TabsTrigger>
            <TabsTrigger value="examples">Example Results</TabsTrigger>
          </TabsList>
          
          <TabsContent value="metrics">
            <ModelMetrics />
            
            <div className="mt-12 grid grid-cols-1 md:grid-cols-2 gap-6">
              <Card>
                <CardHeader>
                  <CardTitle>Dataset Information</CardTitle>
                  <CardDescription>
                    Details about the training and testing datasets
                  </CardDescription>
                </CardHeader>
                <CardContent>
                  <div className="space-y-4">
                    <div className="grid grid-cols-2">
                      <div className="font-medium">Total Images</div>
                      <div>2,500</div>
                    </div>
                    <div className="grid grid-cols-2">
                      <div className="font-medium">Authentic Images</div>
                      <div>1,250</div>
                    </div>
                    <div className="grid grid-cols-2">
                      <div className="font-medium">Forged Images</div>
                      <div>1,250</div>
                    </div>
                    <div className="grid grid-cols-2">
                      <div className="font-medium">Training Split</div>
                      <div>80% (2,000 images)</div>
                    </div>
                    <div className="grid grid-cols-2">
                      <div className="font-medium">Testing Split</div>
                      <div>20% (500 images)</div>
                    </div>
                    <div className="grid grid-cols-2">
                      <div className="font-medium">Forgery Types</div>
                      <div>Copy-move, splicing, object removal, retouching</div>
                    </div>
                  </div>
                </CardContent>
              </Card>
              
              <Card>
                <CardHeader>
                  <CardTitle>Implementation Details</CardTitle>
                  <CardDescription>
                    Technical information about the model implementation
                  </CardDescription>
                </CardHeader>
                <CardContent>
                  <div className="space-y-4">
                    <div className="grid grid-cols-2">
                      <div className="font-medium">Feature Extractor</div>
                      <div>ResNet-18</div>
                    </div>
                    <div className="grid grid-cols-2">
                      <div className="font-medium">Segmentation</div>
                      <div>SLIC with 100 superpixels</div>
                    </div>
                    <div className="grid grid-cols-2">
                      <div className="font-medium">GNN Layers</div>
                      <div>2 graph convolutional layers</div>
                    </div>
                    <div className="grid grid-cols-2">
                      <div className="font-medium">Hidden Dimensions</div>
                      <div>128</div>
                    </div>
                    <div className="grid grid-cols-2">
                      <div className="font-medium">Optimizer</div>
                      <div>Adam (lr=0.001)</div>
                    </div>
                    <div className="grid grid-cols-2">
                      <div className="font-medium">Training Epochs</div>
                      <div>20</div>
                    </div>
                  </div>
                </CardContent>
              </Card>
            </div>
          </TabsContent>
          
          <TabsContent value="examples">
            <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
              {exampleResults.map((example) => (
                <Card key={example.id} className="result-card overflow-hidden">
                  <CardHeader className="p-0">
                    <img 
                      src={example.image} 
                      alt={example.title} 
                      className="w-full h-56 object-cover"
                    />
                  </CardHeader>
                  <CardContent className="p-6">
                    <h3 className="text-xl font-bold mb-2">{example.title}</h3>
                    <p className="text-muted-foreground mb-4">{example.description}</p>
                    <div className="grid grid-cols-3 gap-2 text-center">
                      <div className="bg-muted p-2 rounded">
                        <div className="text-xs text-muted-foreground">Precision</div>
                        <div className="font-bold">{(example.metrics.precision * 100).toFixed(1)}%</div>
                      </div>
                      <div className="bg-muted p-2 rounded">
                        <div className="text-xs text-muted-foreground">Recall</div>
                        <div className="font-bold">{(example.metrics.recall * 100).toFixed(1)}%</div>
                      </div>
                      <div className="bg-muted p-2 rounded">
                        <div className="text-xs text-muted-foreground">F1 Score</div>
                        <div className="font-bold">{(example.metrics.f1Score * 100).toFixed(1)}%</div>
                      </div>
                    </div>
                  </CardContent>
                </Card>
              ))}
            </div>
            
            <div className="mt-12">
              <Card>
                <CardHeader>
                  <CardTitle>Comparison with Other Methods</CardTitle>
                  <CardDescription>
                    Performance comparison with other state-of-the-art forgery detection methods
                  </CardDescription>
                </CardHeader>
                <CardContent>
                  <div className="overflow-x-auto">
                    <table className="w-full">
                      <thead>
                        <tr className="border-b">
                          <th className="text-left p-3">Method</th>
                          <th className="text-left p-3">Precision</th>
                          <th className="text-left p-3">Recall</th>
                          <th className="text-left p-3">F1 Score</th>
                          <th className="text-left p-3">IoU</th>
                        </tr>
                      </thead>
                      <tbody>
                        <tr className="border-b bg-muted">
                          <td className="p-3 font-medium">Our GNN Method</td>
                          <td className="p-3">92.1%</td>
                          <td className="p-3">88.5%</td>
                          <td className="p-3">90.2%</td>
                          <td className="p-3">85.3%</td>
                        </tr>
                        <tr className="border-b">
                          <td className="p-3">CNN-based method</td>
                          <td className="p-3">85.7%</td>
                          <td className="p-3">82.3%</td>
                          <td className="p-3">83.9%</td>
                          <td className="p-3">79.1%</td>
                        </tr>
                        <tr className="border-b">
                          <td className="p-3">Traditional features + SVM</td>
                          <td className="p-3">78.4%</td>
                          <td className="p-3">73.2%</td>
                          <td className="p-3">75.7%</td>
                          <td className="p-3">69.8%</td>
                        </tr>
                        <tr className="border-b">
                          <td className="p-3">Error Level Analysis (ELA)</td>
                          <td className="p-3">72.5%</td>
                          <td className="p-3">68.9%</td>
                          <td className="p-3">70.7%</td>
                          <td className="p-3">64.2%</td>
                        </tr>
                      </tbody>
                    </table>
                  </div>
                </CardContent>
              </Card>
            </div>
          </TabsContent>
        </Tabs>
      </main>
      
      <Footer />
    </div>
  );
};

export default Results;
