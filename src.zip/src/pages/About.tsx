
import React from 'react';
import { Card, CardContent } from "@/components/ui/card";
import Header from '@/components/Header';
import Footer from '@/components/Footer';

const About = () => {
  return (
    <div className="flex flex-col min-h-screen">
      <Header />
      
      <main className="flex-grow container mx-auto px-4 py-8">
        <div className="max-w-4xl mx-auto">
          <h1 className="text-3xl font-bold mb-2">About ForgeryVision</h1>
          <p className="text-muted-foreground mb-8">
            Our mission is to combat digital image manipulation with advanced technology
          </p>
          
          <Card className="mb-8">
            <CardContent className="p-6">
              <h2 className="text-2xl font-bold mb-4">Project Overview</h2>
              <p className="mb-4">
                ForgeryVision is a cutting-edge image forgery detection system that combines computer vision, deep learning, and graph neural networks to identify manipulated images with high accuracy. This project was developed as a minor project to address the growing concern of digital image manipulation and its implications in various domains.
              </p>
              <p className="mb-4">
                Our approach uses a novel graph-based representation of images, where the image is first segmented into superpixels. These superpixels are then treated as nodes in a graph, with edges connecting adjacent regions. This representation allows our algorithm to capture both local anomalies and global inconsistencies that may indicate forgery.
              </p>
              <p>
                The system has been trained on a diverse dataset of authentic and forged images, achieving over 90% precision and recall in identifying various types of image manipulations, including object removal, copy-move forgery, and splicing.
              </p>
            </CardContent>
          </Card>
          
          <div className="grid grid-cols-1 md:grid-cols-2 gap-8 mb-8">
            <Card>
              <CardContent className="p-6">
                <h2 className="text-xl font-bold mb-4">Technical Approach</h2>
                <ul className="space-y-2 list-disc pl-5">
                  <li>Image segmentation using SLIC algorithm</li>
                  <li>Feature extraction with pre-trained ResNet model</li>
                  <li>Graph construction based on superpixel adjacency</li>
                  <li>Graph Neural Network for forgery classification</li>
                  <li>Region-level forgery localization</li>
                  <li>Integration with web application for user-friendly access</li>
                </ul>
              </CardContent>
            </Card>
            
            <Card>
              <CardContent className="p-6">
                <h2 className="text-xl font-bold mb-4">Applications</h2>
                <ul className="space-y-2 list-disc pl-5">
                  <li>Digital forensics and evidence verification</li>
                  <li>News media fact-checking</li>
                  <li>Social media content moderation</li>
                  <li>Insurance claim validation</li>
                  <li>Academic and research integrity</li>
                  <li>Digital art authentication</li>
                </ul>
              </CardContent>
            </Card>
          </div>
          
          <Card className="mb-8">
            <CardContent className="p-6">
              <h2 className="text-2xl font-bold mb-4">The Team</h2>
              <p className="mb-6">
                ForgeryVision was developed by a team of dedicated students with expertise in computer vision, machine learning, and web development.
              </p>
              
              <div className="grid grid-cols-1 sm:grid-cols-2 md:grid-cols-3 gap-6">
                <div className="text-center">
                  <div className="w-24 h-24 rounded-full bg-secondary mx-auto mb-3 flex items-center justify-center">
                    <span className="text-xl font-bold">JD</span>
                  </div>
                  <h3 className="font-bold">John Doe</h3>
                  <p className="text-sm text-muted-foreground">GNN Implementation</p>
                </div>
                
                <div className="text-center">
                  <div className="w-24 h-24 rounded-full bg-secondary mx-auto mb-3 flex items-center justify-center">
                    <span className="text-xl font-bold">JS</span>
                  </div>
                  <h3 className="font-bold">Jane Smith</h3>
                  <p className="text-sm text-muted-foreground">Computer Vision</p>
                </div>
                
                <div className="text-center">
                  <div className="w-24 h-24 rounded-full bg-secondary mx-auto mb-3 flex items-center justify-center">
                    <span className="text-xl font-bold">MP</span>
                  </div>
                  <h3 className="font-bold">Mike Peters</h3>
                  <p className="text-sm text-muted-foreground">Web Development</p>
                </div>
              </div>
            </CardContent>
          </Card>
          
          <Card>
            <CardContent className="p-6">
              <h2 className="text-2xl font-bold mb-4">Technologies Used</h2>
              
              <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                <div>
                  <h3 className="font-bold text-lg mb-2">Backend / ML Pipeline</h3>
                  <ul className="space-y-1 list-disc pl-5">
                    <li>Python 3.8+</li>
                    <li>PyTorch for deep learning</li>
                    <li>PyTorch Geometric for GNN implementation</li>
                    <li>scikit-image for image processing</li>
                    <li>OpenCV for image manipulation</li>
                    <li>NetworkX for graph operations</li>
                    <li>NumPy for numerical operations</li>
                    <li>Flask for API endpoints</li>
                  </ul>
                </div>
                
                <div>
                  <h3 className="font-bold text-lg mb-2">Frontend / Web Application</h3>
                  <ul className="space-y-1 list-disc pl-5">
                    <li>React for UI components</li>
                    <li>TypeScript for type safety</li>
                    <li>Tailwind CSS for styling</li>
                    <li>Shadcn UI for component library</li>
                    <li>Recharts for data visualization</li>
                    <li>Vite for build tooling</li>
                    <li>Node.js for server-side operations</li>
                    <li>Express for RESTful API</li>
                  </ul>
                </div>
              </div>
            </CardContent>
          </Card>
        </div>
      </main>
      
      <Footer />
    </div>
  );
};

export default About;
