
import React, { useState, useRef } from 'react';
import { Upload, X, Image, Loader2 } from 'lucide-react';
import { Button } from "@/components/ui/button";
import { useToast } from "@/components/ui/use-toast";
import { cn } from "@/lib/utils";

interface UploadZoneProps {
  onUpload: (files: File[]) => void;
  isLoading?: boolean;
  accept?: string;
  multiple?: boolean;
  maxSize?: number; // in MB
}

const UploadZone: React.FC<UploadZoneProps> = ({
  onUpload,
  isLoading = false,
  accept = "image/*",
  multiple = false,
  maxSize = 5 // 5MB default
}) => {
  const [isDragging, setIsDragging] = useState(false);
  const [preview, setPreview] = useState<string | null>(null);
  const [selectedFile, setSelectedFile] = useState<File | null>(null);
  const inputRef = useRef<HTMLInputElement>(null);
  const { toast } = useToast();

  const handleFileChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    const files = e.target.files;
    if (!files || files.length === 0) return;
    
    handleFiles(files);
  };

  const handleFiles = (files: FileList) => {
    const file = files[0];
    
    // Check file size
    if (file.size > maxSize * 1024 * 1024) {
      toast({
        title: "File too large",
        description: `Maximum file size is ${maxSize}MB.`,
        variant: "destructive"
      });
      return;
    }
    
    // Create preview
    const reader = new FileReader();
    reader.onload = () => {
      setPreview(reader.result as string);
    };
    reader.readAsDataURL(file);
    
    setSelectedFile(file);
    onUpload(Array.from(files));
  };

  const handleDragOver = (e: React.DragEvent<HTMLDivElement>) => {
    e.preventDefault();
    setIsDragging(true);
  };

  const handleDragLeave = () => {
    setIsDragging(false);
  };

  const handleDrop = (e: React.DragEvent<HTMLDivElement>) => {
    e.preventDefault();
    setIsDragging(false);
    
    if (e.dataTransfer.files && e.dataTransfer.files.length > 0) {
      handleFiles(e.dataTransfer.files);
    }
  };

  const removeFile = () => {
    setPreview(null);
    setSelectedFile(null);
    if (inputRef.current) inputRef.current.value = "";
  };

  const triggerFileInput = () => {
    if (inputRef.current) {
      inputRef.current.click();
    }
  };

  return (
    <div className="w-full">
      {!preview ? (
        <div
          className={cn(
            "upload-zone flex flex-col items-center justify-center p-6 cursor-pointer",
            isDragging && "bg-primary/5",
            isLoading && "opacity-50 cursor-not-allowed"
          )}
          onDragOver={handleDragOver}
          onDragLeave={handleDragLeave}
          onDrop={handleDrop}
          onClick={isLoading ? undefined : triggerFileInput}
        >
          <input
            type="file"
            ref={inputRef}
            className="hidden"
            onChange={handleFileChange}
            accept={accept}
            multiple={multiple}
            disabled={isLoading}
          />
          
          {isLoading ? (
            <Loader2 className="h-10 w-10 text-primary animate-spin mb-4" />
          ) : (
            <Upload className="h-10 w-10 text-primary mb-4" />
          )}
          
          <h3 className="text-lg font-medium mb-1">
            {isLoading ? "Uploading..." : "Drop your image here"}
          </h3>
          <p className="text-sm text-muted-foreground mb-4">
            {isLoading 
              ? "Please wait while we process your image" 
              : "or click to browse files (max. " + maxSize + "MB)"}
          </p>
          
          {!isLoading && (
            <Button type="button" variant="secondary" size="sm" onClick={triggerFileInput}>
              Browse files
            </Button>
          )}
        </div>
      ) : (
        <div className="relative rounded-md overflow-hidden border">
          <div className="absolute top-2 right-2 z-10">
            <Button 
              type="button" 
              variant="destructive" 
              size="sm" 
              className="h-8 w-8 rounded-full p-0" 
              onClick={removeFile}
              disabled={isLoading}
            >
              <X className="h-4 w-4" />
              <span className="sr-only">Remove file</span>
            </Button>
          </div>
          <img 
            src={preview} 
            alt="Preview" 
            className={cn(
              "w-full h-auto object-cover transition-opacity",
              isLoading && "opacity-50"
            )} 
          />
          {isLoading && (
            <div className="absolute inset-0 flex items-center justify-center bg-background/50">
              <Loader2 className="h-8 w-8 text-primary animate-spin" />
            </div>
          )}
        </div>
      )}
    </div>
  );
};

export default UploadZone;
