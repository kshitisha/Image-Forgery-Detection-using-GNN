
import React from 'react';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { 
  BarChart, 
  Bar, 
  XAxis, 
  YAxis, 
  CartesianGrid, 
  Tooltip, 
  ResponsiveContainer,
  LineChart,
  Line
} from 'recharts';

// Sample data - this would be replaced with actual model metrics
const performanceData = [
  { name: 'Precision', value: 0.92 },
  { name: 'Recall', value: 0.88 },
  { name: 'F1 Score', value: 0.90 },
  { name: 'IoU', value: 0.85 }
];

const trainingData = [
  { epoch: 1, loss: 0.85, accuracy: 0.75 },
  { epoch: 2, loss: 0.65, accuracy: 0.81 },
  { epoch: 3, loss: 0.48, accuracy: 0.87 },
  { epoch: 4, loss: 0.35, accuracy: 0.91 },
  { epoch: 5, loss: 0.28, accuracy: 0.93 }
];

interface ModelMetricsProps {
  className?: string;
}

const ModelMetrics: React.FC<ModelMetricsProps> = ({ className }) => {
  return (
    <div className={`space-y-6 ${className}`}>
      <Card>
        <CardHeader>
          <CardTitle>Model Performance Metrics</CardTitle>
          <CardDescription>
            Overall performance metrics of the image forgery detection model
          </CardDescription>
        </CardHeader>
        <CardContent>
          <div className="h-80">
            <ResponsiveContainer width="100%" height="100%">
              <BarChart
                data={performanceData}
                margin={{ top: 20, right: 30, left: 20, bottom: 5 }}
              >
                <CartesianGrid strokeDasharray="3 3" />
                <XAxis dataKey="name" />
                <YAxis domain={[0, 1]} />
                <Tooltip 
                  formatter={(value: number) => [`${(value * 100).toFixed(2)}%`, 'Value']}
                />
                <Bar dataKey="value" fill="hsl(var(--primary))" radius={[4, 4, 0, 0]} />
              </BarChart>
            </ResponsiveContainer>
          </div>
        </CardContent>
      </Card>

      <Card>
        <CardHeader>
          <CardTitle>Training Progress</CardTitle>
          <CardDescription>
            Loss and accuracy metrics during model training
          </CardDescription>
        </CardHeader>
        <CardContent>
          <div className="h-80">
            <ResponsiveContainer width="100%" height="100%">
              <LineChart
                data={trainingData}
                margin={{ top: 20, right: 30, left: 20, bottom: 5 }}
              >
                <CartesianGrid strokeDasharray="3 3" />
                <XAxis dataKey="epoch" />
                <YAxis yAxisId="left" domain={[0, 1]} />
                <YAxis yAxisId="right" orientation="right" domain={[0, 1]} />
                <Tooltip />
                <Line 
                  yAxisId="left"
                  type="monotone" 
                  dataKey="loss" 
                  stroke="#ff7300" 
                  name="Loss"
                  activeDot={{ r: 8 }}
                />
                <Line 
                  yAxisId="right"
                  type="monotone" 
                  dataKey="accuracy" 
                  stroke="hsl(var(--primary))" 
                  name="Accuracy" 
                />
              </LineChart>
            </ResponsiveContainer>
          </div>
        </CardContent>
      </Card>
    </div>
  );
};

export default ModelMetrics;
