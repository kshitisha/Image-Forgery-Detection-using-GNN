
import React, { useEffect, useRef } from 'react';
import { Card, CardContent } from "@/components/ui/card";
import { Progress } from "@/components/ui/progress";

interface ResultsVisualizationProps {
  originalImage: string | null;
  processedImage: string | null;
  metrics: {
    precision: number;
    recall: number;
    f1Score: number;
    iou: number;
    confidence: number;
  } | null;
}

const ResultsVisualization: React.FC<ResultsVisualizationProps> = ({
  originalImage,
  processedImage,
  metrics
}) => {
  const canvasRef = useRef<HTMLCanvasElement>(null);

  useEffect(() => {
    if (canvasRef.current && processedImage) {
      const canvas = canvasRef.current;
      const ctx = canvas.getContext('2d');
      
      if (!ctx) return;
      
      const img = new Image();
      img.onload = () => {
        canvas.width = img.width;
        canvas.height = img.height;
        ctx.drawImage(img, 0, 0);
        
        // Add any additional canvas visualizations here
        // This could include drawing bounding boxes, highlighting forgery regions, etc.
      };
      img.src = processedImage;
    }
  }, [processedImage]);

  if (!originalImage || !metrics) {
    return null;
  }

  // Function to calculate a color based on confidence
  const getConfidenceColor = (confidence: number): string => {
    if (confidence >= 0.8) return 'text-green-500';
    if (confidence >= 0.6) return 'text-yellow-500';
    return 'text-red-500';
  };

  return (
    <div className="animate-fade-in">
      <div className="grid grid-cols-1 md:grid-cols-2 gap-6 mb-6">
        <Card>
          <CardContent className="p-4">
            <h3 className="text-lg font-medium mb-2">Original Image</h3>
            <div className="rounded-md overflow-hidden border">
              <img 
                src={originalImage} 
                alt="Original uploaded image" 
                className="w-full h-auto" 
              />
            </div>
          </CardContent>
        </Card>
        
        <Card>
          <CardContent className="p-4">
            <h3 className="text-lg font-medium mb-2">Processed Result</h3>
            <div className="rounded-md overflow-hidden border">
              {processedImage ? (
                <div className="canvas-container">
                  <canvas ref={canvasRef} />
                </div>
              ) : (
                <div className="aspect-square flex items-center justify-center bg-muted text-muted-foreground">
                  Processing...
                </div>
              )}
            </div>
          </CardContent>
        </Card>
      </div>
      
      <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
        <Card>
          <CardContent className="p-6">
            <h3 className="text-lg font-medium mb-4">Detection Metrics</h3>
            
            <div className="space-y-4">
              <div>
                <div className="flex justify-between mb-1">
                  <span className="text-sm font-medium">Precision</span>
                  <span className="text-sm">{(metrics.precision * 100).toFixed(2)}%</span>
                </div>
                <Progress value={metrics.precision * 100} className="h-2" />
              </div>
              
              <div>
                <div className="flex justify-between mb-1">
                  <span className="text-sm font-medium">Recall</span>
                  <span className="text-sm">{(metrics.recall * 100).toFixed(2)}%</span>
                </div>
                <Progress value={metrics.recall * 100} className="h-2" />
              </div>
              
              <div>
                <div className="flex justify-between mb-1">
                  <span className="text-sm font-medium">F1 Score</span>
                  <span className="text-sm">{(metrics.f1Score * 100).toFixed(2)}%</span>
                </div>
                <Progress value={metrics.f1Score * 100} className="h-2" />
              </div>
              
              <div>
                <div className="flex justify-between mb-1">
                  <span className="text-sm font-medium">IoU</span>
                  <span className="text-sm">{(metrics.iou * 100).toFixed(2)}%</span>
                </div>
                <Progress value={metrics.iou * 100} className="h-2" />
              </div>
            </div>
          </CardContent>
        </Card>
        
        <Card>
          <CardContent className="p-6">
            <h3 className="text-lg font-medium mb-4">Analysis Result</h3>
            
            <div className="mb-6">
              <div className="flex justify-between mb-1">
                <span className="font-medium">Forgery Confidence</span>
                <span className={`font-bold ${getConfidenceColor(metrics.confidence)}`}>
                  {(metrics.confidence * 100).toFixed(2)}%
                </span>
              </div>
              <Progress 
                value={metrics.confidence * 100} 
                className={`h-3 ${
                  metrics.confidence >= 0.8 
                    ? 'bg-green-500' 
                    : metrics.confidence >= 0.6 
                      ? 'bg-yellow-500' 
                      : 'bg-red-500'
                }`}
              />
            </div>
            
            <div className="text-center p-4 rounded-lg border bg-card">
              <h4 className="text-xl font-bold mb-2">
                {metrics.confidence >= 0.75 ? (
                  <span className="text-destructive">Forged Image Detected</span>
                ) : (
                  <span className="text-green-500">Authentic Image</span>
                )}
              </h4>
              <p className="text-muted-foreground">
                {metrics.confidence >= 0.75
                  ? "Our model has detected signs of manipulation in this image."
                  : "No significant signs of manipulation detected in this image."
                }
              </p>
            </div>
          </CardContent>
        </Card>
      </div>
    </div>
  );
};

export default ResultsVisualization;
